/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bootlegwindows;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

/**
 *
 * @author super
 */
public class Window implements Comparable<Window>
{

    private int xOrigin;
    private int yOrigin;
    private int width;
    private int height;
    private Color background;
    private int zOrder;
    public static final int MIN_DIMENSION = 100;

    public Window(int panelWidth, int panelHeight)
    {
        // Creates a random Window inside the bounds of the panel and no smaller
        // than the minimum dimension and no larger than 1/2 of the panel's dimension.
        Random winMaker = new Random();
        width = winMaker.nextInt(panelWidth / 2 - MIN_DIMENSION) + MIN_DIMENSION;
        xOrigin = winMaker.nextInt(panelWidth - width);
        height = winMaker.nextInt(panelHeight / 2 - MIN_DIMENSION) + MIN_DIMENSION;
        yOrigin = winMaker.nextInt(panelHeight - height);
        background = new Color(winMaker.nextInt(255), winMaker.nextInt(255), winMaker.nextInt(255));
    }

    public Window(int width, int height, int xOrigin, int yOrigin, Color background)
    {
        // Allows creation of a custom Window if given all the necessary ifnormation as parameters.
        this.width = width;
        this.height = height;
        this.xOrigin = xOrigin;
        this.yOrigin = yOrigin;
        this.background = background;
    }

    @Override
    public int compareTo(Window other)
    {
        // Compares Windows by their zOrder. A Window on top of another is said to be before it.
        return zOrder - other.getzOrder();
    }

    public void drawWindow(Graphics g)
    {
        // Draws a rectangle to represent the Window with its order and an x to close
        // the window.
        g.setColor(background);
        g.fillRect(xOrigin, yOrigin, width, height);
        String title = "Window " + zOrder;
        Color text = findTextColor(background);
        g.setColor(text);
        g.drawString(title, xOrigin + 5, yOrigin + 15);
        g.drawLine(xOrigin + width - 15, yOrigin + 5, xOrigin + width - 5, yOrigin + 15);
        g.drawLine(xOrigin + width - 15, yOrigin + 15, xOrigin + width - 5, yOrigin + 5);
    }

    public Color findTextColor(Color c)
    {
        // Uses a formula to determine how bright or dark a color is to decide whether white
        // or black text would be more readable given the background color.
        double lum = Math.sqrt(Math.pow(c.getRed(), 2) * 0.299 + Math.pow(c.getGreen(), 2) * 0.587 + Math.pow(c.getBlue(), 2) * 0.114);
        if (lum > 186)
        {
            return Color.BLACK;
        } else
        {
            return Color.WHITE;
        }
    }

    public int getxOrigin()
    {
        return xOrigin;
    }

    public void setxOrigin(int xOrigin)
    {
        this.xOrigin = xOrigin;
    }

    public int getyOrigin()
    {
        return yOrigin;
    }

    public void setyOrigin(int yOrigin)
    {
        this.yOrigin = yOrigin;
    }

    public int getWidth()
    {
        return width;
    }

    public void setWidth(int width)
    {
        this.width = width;
    }

    public int getHeight()
    {
        return height;
    }

    public void setHeight(int height)
    {
        this.height = height;
    }

    public int getzOrder()
    {
        return zOrder;
    }

    public void setzOrder(int zOrder)
    {
        this.zOrder = zOrder;
    }

    public static int getMIN_DIMENSION()
    {
        return MIN_DIMENSION;
    }

}
