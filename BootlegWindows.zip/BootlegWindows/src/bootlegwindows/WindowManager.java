/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bootlegwindows;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

/**
 *
 * @author super
 */
public class WindowManager
{

    private ArrayList<Window> windows;

    public WindowManager(int panelWidth, int panelHeight, int winCount)
    {
        // Creates a given number of random Windows and sets their ordering.
        windows = new ArrayList<Window>();
        for (int i = 0; i < winCount; i++)
        {
            windows.add(new Window(panelWidth, panelHeight));
            windows.get(i).setzOrder(i);
        }
    }

    public void addWindow(int panelWidth, int panelHeight)
    {
        // Adds a new random Window behind all the others and sets its order.
        windows.add(new Window(panelWidth, panelHeight));
        windows.get(windows.size() - 1).setzOrder(windows.size() - 1);
    }

    public void addWindow(int width, int height, int xOrigin, int yOrigin, Color background)
    {
        // Adds a Window with the specified parameters behind all the others and sets its order.
        windows.add(new Window(width, height, xOrigin, yOrigin, background));
        windows.get(windows.size() - 1).setzOrder(windows.size() - 1);
    }

    public void bringToFront(Window w)
    {
        // Changes the zOrder of the given Window and shifts all the ones before it
        // down by 1 and then sorts using the Window's compareTo method.
        int index = w.getzOrder();
        windows.get(index).setzOrder(0);
        for (int i = 0; i < index; i++)
        {
            windows.get(i).setzOrder(i+1);
        }
        windows.sort(null);
    }

    public void closeWindow(Window w)
    {
        // Removes the given Window and shifts the Windows after it up by 1
        int index = w.getzOrder();
        for (int i = index + 1; i < windows.size(); i++)
        {
            windows.get(i).setzOrder(i-1);
        }
        windows.remove(index);
    }
    
    public Window findWindowByPosition(MouseEvent me)
    {
        // Uses a mouse event to determine which Window the mouse event interacts with.
        // Goes down in order from the top, and as soon as a fitting Window is bound the
        // loop is exited.
        int x = me.getX();
        int y = me.getY();
        for (int i = 0; i < windows.size(); i++)
        {
            Window w = windows.get(i);
            if (w.getxOrigin()<= x && x <= w.getxOrigin() + w.getWidth() && w.getyOrigin()<= y && y <= w.getyOrigin() + w.getHeight() )
            {
                return w;
            }
        }
        return null;
    }

    public void drawWindows(Graphics g)
    {
        // Draws the Windows in reverse order so that the first one is on top
        for (int i = windows.size() - 1; i >= 0; i--)
        {
            windows.get(i).drawWindow(g);
        }
    }

    public ArrayList<Window> getWindows()
    {
        return windows;
    }

}
